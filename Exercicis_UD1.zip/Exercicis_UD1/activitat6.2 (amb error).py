a = [5, 10, 15]
b = 20

if 5 in a:
    b -= 5
elif 10 in a:
    b -= 10
else 15 in a:
    b -= 15

print(b)
