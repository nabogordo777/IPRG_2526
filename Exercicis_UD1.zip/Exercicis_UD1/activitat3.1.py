def saludar(nom):
    print(f"Hola, {nom}!")

saludar("Pau")
saludar("Carla")
