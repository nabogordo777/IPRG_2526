num1 = float(input("Introdueix el primer número: "))
num2 = float(input("Introdueix el segon número: "))

if num1 > num2:
    print("El primer número és més gran que el segon.")
elif num1 < num2:
    print("El primer número és més petit que el segon.")
else:
    print("Els dos números són iguals.")
