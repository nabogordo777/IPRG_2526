def sumar(num1, num2=5):
    return num1 + num2

print(sumar(10))

print(sumar(10, 3))
