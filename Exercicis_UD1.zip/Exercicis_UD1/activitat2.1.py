estudiants = ["Anna", "Joan", "Maria", "Pau", "Laura"]

estudiants.append("Carles")
print("Llista d'estudiants després d'afegir Carles:", estudiants)

del estudiants[1]
print("Llista d'estudiants després d'eliminar el segon:", estudiants)
