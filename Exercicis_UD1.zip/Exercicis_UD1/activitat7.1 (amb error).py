x = 10
y = 5

if x = y:
    print("Són iguals")
else:
    print("Són diferents")