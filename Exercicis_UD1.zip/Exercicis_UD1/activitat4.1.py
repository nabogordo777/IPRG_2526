x = 10
y = 5

print(f"Suma: {x + y}")
print(f"Resta: {x - y}")
print(f"Multiplicació: {x * y}")
print(f"Divisió: {x / y}")
print(f"Divisió entera: {x // y}")
print(f"Mòdul: {x % y}")

print(f"x és més gran que y: {x > y}")
print(f"x és igual a y: {x == y}")
print(f"x és més gran que y i x és parell: {x > y and x % 2 == 0}")
