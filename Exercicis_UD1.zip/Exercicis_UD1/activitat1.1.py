num1 = float(input("Introdueix el primer número: "))
num2 = float(input("Introdueix el segon número: "))

print(f"Suma: {num1 + num2}")
print(f"Resta: {num1 - num2}")
print(f"Multiplicació: {num1 * num2}")
print(f"Divisió: {num1 / num2}")
print(f"Divisió entera: {num1 // num2}")
print(f"Mòdul: {num1 % num2}")

text1 = input("Introdueix el primer text: ")
text2 = input("Introdueix el segon text: ")
print(f"Concatenació: {text1 + text2}")

